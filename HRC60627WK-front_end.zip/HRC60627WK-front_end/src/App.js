import React from "react"

import Header from "./components/header"
import { styled } from "@mui/material"
import Footer from "./components/footer"
import MainTable from "./components/mainTable"

const PageContainer = styled("div")(() => ({
	backgroundColor: "#2c4151",
	width: "100vw",
	height: "100vh",
	display: "flex",
	flexDirection: "column",
	alignItems: "center",
}))

function App() {
	return (
		<PageContainer className="App">
			<Header></Header>
			<h3 style={{color: 'white', fontSize: '16px'}}>&emsp;Invoice List</h3>
			<MainTable></MainTable>
			<Footer></Footer>
		</PageContainer>
	)
}

export default App
