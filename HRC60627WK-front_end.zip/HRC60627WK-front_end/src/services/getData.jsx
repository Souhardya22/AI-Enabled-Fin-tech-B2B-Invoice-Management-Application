import axios from "axios";

const getData = (page, pageSize, order, orderBy, seacrhInput, isAdv, advSearchData) => {
   if (isAdv == true) {
      return new Promise((resolve, reject) => {
         axios.post("http://localhost:8080/Crud_Web_App/DisplayServlet", {}, {
            params: {
               page: page,
               page_size: pageSize,
               isAdv: isAdv,
               documentID: advSearchData.documentID,
               invoiceID: advSearchData.invoiceID,
               customerNumber: advSearchData.customerNumber,
               businessYear: advSearchData.businessYear
            }
         }).then(response => {
            resolve(response.data)
            return response.data;
         }).catch(err => {
            reject(err)
            console.log(err);
         })
      })
   }
   return new Promise((resolve, reject) => {
      axios.post("http://localhost:8080/Crud_Web_App/DisplayServlet", {}, {
         params: {
            page: page,
            page_size: pageSize,
            order: order,
            order_by: orderBy,
            search_input: seacrhInput
         }
      }).then(response => {
         resolve(response.data)
         return response.data;
      }).catch(err => {
         reject(err)
         console.log(err);
      })
   })
}
export {getData}
