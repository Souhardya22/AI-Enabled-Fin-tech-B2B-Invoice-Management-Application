import { styled, alpha } from "@mui/material/styles"
import InputBase from "@mui/material/InputBase"
import Button from "@mui/material/Button"

//?Styling for the main add/delete/delete buttons

const Search = styled("div")(({ theme }) => ({
	color: "#fefefe",
	position: "relative",
	borderRadius: "10px",
	backgroundColor: alpha("#fefefe", 0.3),
	"&:hover": {
		backgroundColor: alpha("#fefefe", 0.5),
	},
	marginRight: "2rem",
	marginLeft: 0,
	width: "100%",
	[theme.breakpoints.up("sm")]: {
		marginLeft: theme.spacing(3),
		width: "auto",
	},
}))

const SearchIconWrapper = styled("div")(({ theme }) => ({
	padding: "0 0.6rem",
	height: "100%",
	position: "absolute",
	pointerEvents: "none",
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
}))

const StyledInputBase = styled(InputBase)(({ theme }) => ({
	color: "inherit",
	"& .MuiInputBase-input": {
		padding: "0.5rem 0.5rem 0.5rem 0",
		paddingLeft: `calc(1rem + 0.7*3rem)`,
		transition: theme.transitions.create("width"),
		width: "100%",
		[theme.breakpoints.up("md")]: {
			width: "20ch",
		},
	},
}))

const FlexBox = styled("div")(() => ({
	width: "90vw",
	height: "4rem",
	backgroundColor: "none",
	display: "flex",
	flexDirection: "row",
	justifyContent: "space-between",
	alignItems: "center",
	color: "#333",
}))

const StyledCustomButton = styled(Button)((theme) => ({
	fontSize: "0.6rem",
	width: theme.width,
	height: "2rem",
	color: "#fefefe",
}))

const DataGridStyle = {
	color: "#fefefe",
	fontSize: "0.8rem",
	border: "2px solid rgba(255,255,255, 0.2)",
	"& .MuiCheckbox-root .MuiSvgIcon-root": {
		color: "#fefefe",
		fontSize: "1rem",
	},
	"& .MuiCheckbox-root .Mui-checked": {
		color: "#1976d2",
	},
	"& .MuiDataGrid-iconSeparator": {
		display: "none",
	},
	"& .MuiDataGrid-columnHeaders": {
		borderBottom: `none`,
		backgroundColor: "rgba(255,255,255,0.15)",
	},
	"& .MuiDataGrid-footerContainer": {
		border: `none`,
		backgroundColor: "rgba(255,255,255,0.15)",
		color: "#fefefe",
	},
	"& .MuiDataGrid-footerContainer .MuiTablePagination-root": {
		color: "#fefefe !important",
	},
	"& .MuiDataGrid-columnsContainer, .MuiDataGrid-cell": {
		borderBottom: `2px solid rgba(255,255,255, 0.2)`,
	},
	"& .MuiDataGrid-cell": {
		color: "#fefefe",
	},
	".MuiDataGrid-columnHeader :hover .MuiDataGrid-sortIcon": {
		color: "#fefefe",
	},
	".MuiDataGrid-columnHeader .MuiDataGrid-sortIcon": {
		color: "#fefefe",
	},
	".MuiDataGrid-columnHeader .MuiDataGrid-menuIcon button svg": {
		color: "#fefefe",
	},
}

export {
	Search,
	SearchIconWrapper,
	StyledInputBase,
	StyledCustomButton,
	FlexBox,
	DataGridStyle
}
