package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.service.AddDataService;
/**
 * Servlet implementation class AddData
 */
@WebServlet("/AddData")
public class AddData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       AddDataService service = new AddDataService();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String business_Code=request.getParameter("business_Code");
		String customer_Number=request.getParameter("customer_Number");
		String clear_Date=request.getParameter("clear_Date");
		String business_Year=request.getParameter("business_Year");
		String document_ID=request.getParameter("document_ID");
		String posting_Date=request.getParameter("posting_Date");
		String document_Create_Date=request.getParameter("document_Create_Date");
		String due_Date=request.getParameter("due_Date");
		String invoice_Currency=request.getParameter("invoice_Currency");
		String document_Type=request.getParameter("document_Type");
		String posting_ID=request.getParameter("posting_ID");
		String total_Open_Amount=request.getParameter("total_Open_Amount");
		String baseline_Create_Date=request.getParameter("baseline_Create_Date");
		String customer_Payment_Terms=request.getParameter("customer_Payment_Terms");
		String invoice_ID=request.getParameter("invoice_ID");
		
		
		String isInserted= service.addData(business_Code,customer_Number,clear_Date,business_Year,document_ID,posting_Date,document_Create_Date,due_Date,invoice_Currency,document_Type,posting_ID,total_Open_Amount,baseline_Create_Date,customer_Payment_Terms,invoice_ID);
		//System.out.println(business_Code);
		System.out.println(isInserted);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
