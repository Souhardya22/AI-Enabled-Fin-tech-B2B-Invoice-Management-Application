package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.FetchDataService;
import com.google.gson.*;
import com.model.Dataset;

/**
 * Servlet implementation class DisplayServlet
 */
@WebServlet(urlPatterns= {"/DisplayServlet"}, name="DisplayServlet", description="DisplayServlet returns a JSON object")
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private FetchDataService service= new FetchDataService();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<Dataset> arr= new ArrayList<>();
		//FetchDataService data= new FetchDataService();
		int page=Integer.parseInt(request.getParameter("page"));
		int pageSize=Integer.parseInt(request.getParameter("page_size"));
		int lower=page*pageSize;
		int upper=pageSize;
		
		boolean isAdv=Boolean.parseBoolean(request.getParameter("isAdv"));
		
		if(isAdv) {
			String documentID= request.getParameter("documentID");
			String invoiceID= request.getParameter("invoiceID");
			String customerNumber= request.getParameter("customerNumber");
			String businessYear= request.getParameter("businessYear");
			arr=service.getData(lower, upper, documentID, invoiceID, customerNumber, businessYear);
		}
		else {
			String order=request.getParameter("order");
			String orderBy=request.getParameter("order_by");
			String searchInput=request.getParameter("search_input");
			arr=service.getData(lower, upper,order, orderBy, searchInput);
		}
		
		Gson gson = new Gson();
		String winterJSON= gson.toJson(arr);
		PrintWriter printWriter=response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		printWriter.write(winterJSON);
		printWriter.close();
		
				
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
