package com.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DeleteDataService {
	public String deleteData(String selectedRows) {
		System.out.println("getData called!");
        String user="root";
        String password= "511MySQL@15";
        //Name of the database is grey_goose and we'll be fetching the data from the winter_intership table
        Connection connection;
        
        try {
        	//List<Dataset> select10 = new ArrayList<>();
        	Class.forName("com.mysql.cj.jdbc.Driver");
 			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose",user,password);
 			if(connection!=null) {
 				System.out.println("Datatabse Connected");
 			}
 			
 			PreparedStatement statement=connection.prepareStatement("DELETE FROM winter_internship WHERE sl_no in ("+selectedRows+")");
 			//statement.setString(1, selectedRows);
	        int affectedRows= statement.executeUpdate();
 			
 			return (affectedRows+" rows have been deleted!");
        }
        catch(Exception e) {
        	e.printStackTrace();
        }
		return "Unable to delete";
	}
}
