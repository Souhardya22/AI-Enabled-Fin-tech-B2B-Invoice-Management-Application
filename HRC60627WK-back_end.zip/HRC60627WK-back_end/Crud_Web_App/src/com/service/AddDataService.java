package com.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Date;

public class AddDataService {
	public String addData(String business_Code, String customer_Number,String clear_Date,String business_Year,String document_ID,String posting_Date,String document_Create_Date,String due_Date,String invoice_Currency,String document_Type,String posting_ID,String total_Open_Amount,String baseline_Create_Date,String customer_Payment_Terms,String invoice_ID){
		System.out.println("getData called!");
        String user="root";
        String password= "511MySQL@15";
        //Name of the database is grey_goose and we'll be fetching the data from the winter_intership table
        Connection connection;
        
        try {
        	//List<Dataset> select10 = new ArrayList<>();
        	Class.forName("com.mysql.cj.jdbc.Driver");
 			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose",user,password);
 			if(connection!=null) {
 				System.out.println("Datatabse Connected");
 			}
 			
			//Statement stmnt = connection.createStatement();
 			PreparedStatement setOptions=connection.prepareStatement("SET FOREIGN_KEY_CHECKS = 0");
 			setOptions.execute();
 			PreparedStatement statement=connection.prepareStatement("INSERT INTO winter_internship (business_code , cust_number , clear_date , buisness_year , doc_id , posting_date , document_create_date , due_in_date , invoice_currency , document_type , posting_id , total_open_amount , baseline_create_date , cust_payment_terms , invoice_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
 			statement.setString(1,business_Code);
 			statement.setInt(2,Integer.parseInt(customer_Number));
 			statement.setDate(3,Date.valueOf(clear_Date));
 			statement.setInt(4,Integer.parseInt(business_Year));
 			statement.setString(5,document_ID);
 			statement.setDate(6,Date.valueOf(posting_Date));
 			statement.setDate(7,Date.valueOf(document_Create_Date));
 			statement.setDate(8,Date.valueOf(due_Date));
 			statement.setString(9,invoice_Currency);
 			statement.setString(10,document_Type);
 			statement.setInt(11,Integer.parseInt(posting_ID));
 			statement.setDouble(12,Float.parseFloat(total_Open_Amount));
 			statement.setDate(13,Date.valueOf(baseline_Create_Date));
 			statement.setString(14,customer_Payment_Terms);
 			statement.setInt(15,Integer.parseInt(invoice_ID));
 			
 			/*
 			System.out.println(business_Code);
 			System.out.println(Integer.parseInt(customer_Number));
 			System.out.println(Date.valueOf(clear_Date));
 			System.out.println(1111);
 			System.out.println(document_ID);
 			System.out.println(Date.valueOf(posting_Date));
 			System.out.println(Date.valueOf(document_Create_Date));
 			System.out.println(Date.valueOf(due_Date));
 			System.out.println(invoice_Currency);
 			System.out.println(document_Type);
 			System.out.println(Integer.parseInt(posting_ID));
 			System.out.println(Float.parseFloat(total_Open_Amount));
 			System.out.println(Date.valueOf(baseline_Create_Date));
 			System.out.println(customer_Payment_Terms);
 			System.out.println(Integer.parseInt(invoice_ID));
 			*/
	        int affectedRows = statement.executeUpdate();
 			
 			return (affectedRows+" Inserted Sucessfully");
        }
        catch(Exception e) {
        	e.printStackTrace();
        }
        return "Unable to insert";
	}
}

 			