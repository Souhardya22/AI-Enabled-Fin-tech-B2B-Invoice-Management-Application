package com.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class EditDataService {
	public String editData(String selectedRow, String invoiceCurrency, String custPaymentTerms) {
        String user="root";
        String password= "511MySQL@15";
        //Name of the database is grey_goose and we'll be fetching the data from the winter_intership table
        Connection connection;
        
        try {
        	//List<Dataset> select10 = new ArrayList<>();
        	Class.forName("com.mysql.cj.jdbc.Driver");
 			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose",user,password);
 			if(connection!=null) {
 				System.out.println("Datatabse Connected");
 			}
 			
 			PreparedStatement statement=connection.prepareStatement("UPDATE winter_internship SET invoice_currency=?, cust_payment_terms=? WHERE sl_no="+selectedRow);
 			//statement.setString(1, selectedRows);
 			statement.setString(1, invoiceCurrency);
 	        statement.setString(2, custPaymentTerms);
	        int affectedRows= statement.executeUpdate();
 			
 			return (affectedRows+" rows have been edited!");
        }
        catch(Exception e) {
        	e.printStackTrace();
        }
		return "Unable to Edit Data";
	}
}
