package com.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Dataset;


public class FetchDataService {
	public List<Dataset> getData(int lower,int upper, String order, String orderBy, String searchInput){
		System.out.println("getData called!");
        String user="root";
        String password= "511MySQL@15";
        //Name of the database is grey_goose and we'll be fetching the data from the winter_intership table
        Connection connection;
        
        try {
        	List<Dataset> select10 = new ArrayList<>();
        	Class.forName("com.mysql.cj.jdbc.Driver");
 			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose",user,password);
 			if(connection!=null) {
 				System.out.println("Datatabse Connected");
 			}
 			
			//Statement stmnt = connection.createStatement();
 			PreparedStatement statement=connection.prepareStatement("SELECT * FROM winter_internship WHERE cust_number LIKE ? LIMIT ?,?");
 			statement.setString(1, (searchInput+"%"));
 			statement.setInt(2,lower);
 			statement.setInt(3, upper);
	        ResultSet data = statement.executeQuery();
	        
	        while(data.next()) {
	        	Dataset item=new Dataset(data.getInt(1), data.getString(2), data.getInt(3), data.getString(4), data.getInt(5), data.getString(6), data.getString(7),data.getString(8), data.getString(9), data.getString(10), data.getString(11), data.getString(12), data.getInt(13), data.getString(14), data.getDouble(15), data.getString(16), data.getString(17), data.getInt(18), data.getInt(19), data.getInt(20), data.getInt(21));
	        	
	        	//item.display();
	        	
	            select10.add(item);
	        }
	        
	        return select10;
            
        } catch (SQLException | ClassNotFoundException e) {
            //TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
	}
	public List<Dataset> getData(int lower,int upper, String documentID,String invoiceID,String customerNumber,String businessYear){
		System.out.println("Advanced Search getData called!");
        String user="root";
        String password= "511MySQL@15";
        //Name of the database is grey_goose and we'll be fetching the data from the winter_intership table
        Connection connection;
        
        try {
        	List<Dataset> select10 = new ArrayList<>();
        	Class.forName("com.mysql.cj.jdbc.Driver");
 			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose",user,password);
 			if(connection!=null) {
 				System.out.println("Datatabse Connected");
 			}
 			
			//Statement stmnt = connection.createStatement();
 			PreparedStatement statement=connection.prepareStatement("SELECT * FROM winter_internship WHERE doc_id=? AND invoice_id=? AND cust_number=? AND buisness_year=? LIMIT ?, ?;");

 			statement.setString(1, documentID);
 			statement.setLong(2,Long.parseLong(invoiceID));
 			statement.setLong(3, Long.parseLong(customerNumber));
 			statement.setInt(4, Integer.parseInt(businessYear));
 			statement.setInt(5, lower);
 			statement.setInt(6, upper);
 			
 			System.out.println(documentID);
 			System.out.println(invoiceID);
 			System.out.println(customerNumber);
 			System.out.println(businessYear);
 			
	        ResultSet data = statement.executeQuery();
	        
	        while(data.next()) {
	        	Dataset item=new Dataset(data.getInt(1), data.getString(2), data.getInt(3), data.getString(4), data.getInt(5), data.getString(6), data.getString(7),data.getString(8), data.getString(9), data.getString(10), data.getString(11), data.getString(12), data.getInt(13), data.getString(14), data.getDouble(15), data.getString(16), data.getString(17), data.getInt(18), data.getInt(19), data.getInt(20), data.getInt(21));
	        	//item.display();
	        	
	            select10.add(item);
	        }
	        
	        
	        return select10;
            
        } catch (SQLException | ClassNotFoundException e) {
            //TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
	}

}
